import Link from "next/link";
import {
  Truck,
  Gift,
  Phone,
  Mail,
  UserRound,
  UserPlus,
} from "lucide-react";

export function TopInfoBar() {
  return (
    <div className="hidden lg:block border-b border-gray-100 text-sm">
      <div className="container mx-auto px-4">
        <div className="flex h-10 items-center justify-between">

          {/* Left: Store benefits */}
          <div className="flex items-center gap-6 text-gray-500">
            <span className="flex items-center gap-2">
              <Truck className="size-3.5 text-primary" aria-hidden="true" />
              <span>Free Shipping on Orders 500 EGP</span>
            </span>

            <span className="flex items-center gap-2">
              <Gift className="size-3.5 text-primary" aria-hidden="true" />
              <span>New Arrivals Daily</span>
            </span>
          </div>

          {/* Right: Contact and account */}
          <div className="flex items-center gap-6">

            {/* Contact information */}
            <div className="flex items-center gap-4 text-gray-500">
              <a
                href="tel:+18001234567"
                className="flex items-center gap-1.5 transition-colors hover:text-primary"
              >
                <Phone className="size-3.5" aria-hidden="true" />
                <span>+1 (800) 123-4567</span>
              </a>

              <a
                href="mailto:support@freshcart.com"
                className="flex items-center gap-1.5 transition-colors hover:text-primary"
              >
                <Mail className="size-3.5" aria-hidden="true" />
                <span>support@freshcart.com</span>
              </a>
            </div>

            <span className="h-4 w-px bg-gray-200" />

            {/* Authentication links */}
            <div className="flex items-center gap-4">
              <Link
                href="/login"
                className="flex items-center gap-1.5 text-gray-600 transition-colors hover:text-primary"
              >
                <UserRound className="size-3.5" aria-hidden="true" />
                <span>Sign In</span>
              </Link>

              <Link
                href="/signup"
                className="flex items-center gap-1.5 text-gray-600 transition-colors hover:text-primary"
              >
                <UserPlus className="size-3.5" aria-hidden="true" />
                <span>Sign Up</span>
              </Link>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}
